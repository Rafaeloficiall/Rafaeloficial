<section id="multiple-column-form">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">UPLOAD DE BACKGROUNDS</h4>
					<p class="px-0"><b>Tamanho recomendado (1980px x 1080px).png ou jpg</b>
					
                </div>
				
                <div class="card-body">
<center><p class="px-0"><b>BACKGROUND REVENDA ATUAL</b></p>
<p><a href="/app-assets/images/background/painel-rv.png"><img src="/app-assets/images/background/painel-rv.png" alt="Image" height="150" width="250"></a></p>
<p><b>AQUI FAZ UPLOAD DO BACKGROUND <br/>REVENDA.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeBkrv.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>
    </form>
</div>

<center><p class="px-0"><b>BACKGROUND ADMIN ATUAL</b></p>
<p><a href="/app-assets/images/background/painel-ad.png"><img src="/app-assets/images/background/painel-ad.png" alt="Image" height="150" width="250"></a></p>
<p><b>AQUI FAZ UPLOAD  DO BACKGROUND <br/>ADMIN.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeBkad.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
	   <p>
				</p>		
    </form>
	
</br>
<center><p class="px-0"><b>BACKGROUND DA LOJA ATUAL</b></p>
<p><a href="/app-assets/images/background/store-bk.png"><img src="/app-assets/images/background/store-bk.png" alt="Image" height="150" width="250"></a></p>
<p><b>AQUI FAZ UPLOAD DO BACKGROUND DA <br/>LOJA.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeStore.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>
	
<br/>
<div class="card-header">
<h4 class="card-title">UPLOAD DAS IMAGES DOS APPS</h4>
	<p class="px-0"><b>Tamanho recomendado (512px x 512px).png</b>
</div>
	<center><p class="px-0"><b>IMAGEM ATUAL APP-V1</b></p>
<p><a href="/apps/img/app-vpn-01.png"><img src="/apps/img/app-vpn-01.png" alt="Image" height="100" width="100"></a></p>
<p><b>AQUI FAZ UPLOAD DA IMAGEM<br/>APP-V1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeApp1.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
</form>

<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL APP-V2</b></p>
<p><a href="/apps/img/app-vpn-02.png"><img src="/apps/img/app-vpn-02.png" alt="Image" height="100" width="100"></a></p>
<p><b>AQUI FAZ UPLOAD DA IMAGEM<br/>APP-V1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeApp2.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>
	
<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL APP-V3</b></p>
<p><a href="/apps/img/app-vpn-03.png"><img src="/apps/img/app-vpn-03.png" alt="Image" height="100" width="100"></a></p>
<p><b>AQUI FAZ UPLOAD DA IMAGEM<br/>APP-V3.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeApp3.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
	
<br/>
<div class="card-header">
<h4 class="card-title">UPLOAD DAS IMAGES DOS AVATAR</h4>
	<p class="px-0"><b>Tamanho recomendado (470px x 470px).png</b>
</div>
	<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 1</b></p>
		<p>
			<a href="/app-assets/images/avatars/avatar1.png"><img src="/app-assets/images/avatars/avatar1.png" alt="Image" height="100" width="100"></a>
		</p>
<p><b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar1.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
</form>	

<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 2</b></p>
	<p>
		<a href="/app-assets/images/avatars/avatar2.png"><img src="/app-assets/images/avatars/avatar2.png" alt="Image" height="100" width="100"></a>
	</p>
	<p>
		<b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 2.</b>
	</p>
</center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar2.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>
	
<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 3</b></p>
	<p>
		<a href="/app-assets/images/avatars/avatar3.png"><img src="/app-assets/images/avatars/avatar3.png" alt="Image" height="100" width="100"></a>
	</p>
	<p>
		<b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 3.</b>
	</p>
</center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar3.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>

<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 4</b></p>
	<p>
		<a href="/app-assets/images/avatars/avatar4.png"><img src="/app-assets/images/avatars/avatar4.png" alt="Image" height="100" width="100"></a>
	</p>
	<p>
		<b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 4.</b>
	</p>
</center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar4.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
	
<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 5</b></p>
	<p>
		<a href="/app-assets/images/avatars/avatar5.png"><img src="/app-assets/images/avatars/avatar5.png" alt="Image" height="100" width="100"></a>
	</p>
	<p>
		<b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 5.</b>
	</p>
</center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar5.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
	
<br/><br/>
<center><p class="px-0"><b>IMAGEM ATUAL DO AVATAR 6</b></p>
	<p>
		<a href="/app-assets/images/avatars/avatar6.png"><img src="/app-assets/images/avatars/avatar6.png" alt="Image" height="100" width="100"></a>
	</p>
	<p>
		<b>AQUI FAZ UPLOAD DA IMAGEM<br/>AVATAR 6.</b>
	</p>
</center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeAvatar6.php">
       
	  <center><input name="arquivo" type="file" />
       <input type="submit" value="Salvar" /> </center><br/>
    </form>	
<br/>	
                </div>
            </div>
        </div>
    </div>	
</section>